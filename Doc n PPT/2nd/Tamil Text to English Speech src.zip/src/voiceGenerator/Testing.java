package voiceGenerator;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.UnknownHostException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.sound.sampled.UnsupportedAudioFileException;

import marytts.client.MaryClient;
import marytts.client.http.Address;
import marytts.util.data.audio.AudioPlayer;

public class Testing {

	public static void main(String[] args)
			throws IOException, UnknownHostException, UnsupportedAudioFileException,
			InterruptedException
	{
		String serverHost = System.getProperty("server.host", "localhost");
		int serverPort = Integer.getInteger("server.port", 59125).intValue();
		MaryClient mary = MaryClient.getMaryClient(new Address(serverHost, serverPort));
		String text = "He reads book";
		String locale = "en_US";
		String inputType = "TEXT";
		String outputType = "AUDIO";
		String audioType = "WAVE";
		String defaultVoiceName = null;
		FileOutputStream fos = new FileOutputStream("C:\\Users\\mrsiva268\\Desktop\\filename.wav");
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		mary.process(text, inputType, outputType, locale, audioType, defaultVoiceName, fos);
		System.out.println("File saved");
		mary.process(text, inputType, outputType, locale, audioType, defaultVoiceName, baos);
		// The byte array constitutes a full wave file, including the headers.
		// And now, play the audio data:
		AudioInputStream ais = AudioSystem.getAudioInputStream(
				new ByteArrayInputStream(baos.toByteArray()));
		LineListener lineListener = new LineListener() {
			public void update(LineEvent event) {
				if (event.getType() == LineEvent.Type.START) {
					System.err.println("Audio started playing.");
				} else if (event.getType() == LineEvent.Type.STOP) {
					System.err.println("Audio stopped playing.");
				} else if (event.getType() == LineEvent.Type.OPEN) {
					System.err.println("Audio line opened.");
				} else if (event.getType() == LineEvent.Type.CLOSE) {
					System.err.println("Audio line closed.");
				}
			}
		};

		AudioPlayer ap = new AudioPlayer(ais, lineListener);
		ap.start();
	}
}