package voiceGenerator;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.sound.sampled.UnsupportedAudioFileException;

import marytts.client.MaryClient;
import marytts.client.http.Address;
import marytts.util.data.audio.AudioPlayer;
import UNLWordFormat.*;

/* Emotion Constants
 * 0- Happy 
 * 1 - Sad
 * 2 - cry
 * 3 - laughter 
 */

public class voiceGenerator {

	public int IdentifyEmotions(UNLGraph UNLnode)
	{
		return 0;
	}

	public void addEmotionsToVoice(String filePath,int Emotion,String modifiedFilePath)
	{

	}

	public void TTS(String text, String tempFileStroragePath)
	{
		try {
			//Runtime.getRuntime().exec("cmd /c start C:\\Users\\mrsiva268\\MARYTTS\\bin\\maryserver.bat");
			//Thread.sleep(9000);
			String serverHost = System.getProperty("server.host", "localhost");
			int serverPort = Integer.getInteger("server.port", 59125).intValue();
			MaryClient mary;

			mary = MaryClient.getMaryClient(new Address(serverHost, serverPort));
			String locale = "en_US";
			String inputType = "TEXT";
			String outputType = "AUDIO";
			String audioType = "WAVE";
			String defaultVoiceName = null;
			FileOutputStream fos = new FileOutputStream(tempFileStroragePath);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			mary.process(text, inputType, outputType, locale, audioType, defaultVoiceName, fos);
			System.out.println("File saved");
			mary.process(text, inputType, outputType, locale, audioType, defaultVoiceName, baos);
			// The byte array constitutes a full wave file, including the headers.
			// And now, play the audio data:
			AudioInputStream ais = AudioSystem.getAudioInputStream(
					new ByteArrayInputStream(baos.toByteArray()));
			LineListener lineListener = new LineListener() {
				public void update(LineEvent event) {
					if (event.getType() == LineEvent.Type.START) {
						System.err.println("Audio started playing.");
					} else if (event.getType() == LineEvent.Type.STOP) {
						System.err.println("Audio stopped playing.");
					} else if (event.getType() == LineEvent.Type.OPEN) {
						System.err.println("Audio line opened.");
					} else if (event.getType() == LineEvent.Type.CLOSE) {
						System.err.println("Audio line closed.");
					}
				}
			};

			AudioPlayer ap = new AudioPlayer(ais, lineListener);
			ap.start();
			//மாட்ளாப்
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedAudioFileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/* for now u can start directly on converting Input to text .. After the Structure OF UNL graph is finalised
	 * u can work on emotion identification from UNL 
	 * filepathTostore- the path where u ll store the output
	 * Input example - He is reading a book 
	 * */

	public void generateVoice(UNLGraph UNLnode,String Input, String fileName) {

		//int identifiedEmotion=IdentifyEmotions(UNLnode);
		TTS(Input,fileName);
		//addEmotionsToVoice(TTSStoragePath,identifiedEmotion,filePathToStore);

	}
	public static void main(String[] args){
		voiceGenerator vG = new voiceGenerator();
		vG.TTS("He is reading a book", "C:\\Users\\mrsiva268\\Desktop\\filename.wav");
	}
}
