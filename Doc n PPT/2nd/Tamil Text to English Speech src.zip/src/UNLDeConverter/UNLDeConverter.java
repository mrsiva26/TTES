package UNLDeConverter;
import UNLWordFormat.*;
import simplenlg.framework.*;
import simplenlg.lexicon.*;
import simplenlg.realiser.english.*;
import simplenlg.phrasespec.*;
import simplenlg.features.*;

public class UNLDeConverter {

	Lexicon lexicon;
	NLGFactory nlgFactory;
	Realiser realiser;
	
	public UNLDeConverter()
	{
		lexicon = Lexicon.getDefaultLexicon();
        nlgFactory = new NLGFactory(lexicon);
        realiser = new Realiser(lexicon);
	}
	
	public String SVOform(String subject,String verb,String object,String tense){
		
		SPhraseSpec p = nlgFactory.createClause();
        p.setSubject(subject);
        p.setVerb(verb);
        p.setObject(object);
        
        if(tense=="past")
        	p.setFeature(Feature.TENSE, Tense.PAST);
        else if(tense=="future")
        	p.setFeature(Feature.TENSE, Tense.FUTURE);
        else
        	p.setFeature(Feature.TENSE, Tense.PRESENT);
        String output = realiser.realiseSentence(p);
        return output;
	}

	public String SVOAform(String subject,String verb,String object,String Adjunct,String tense){
		
		SPhraseSpec p = nlgFactory.createClause();
        p.setSubject("Mary");
        p.setVerb("chase");
        p.setObject("the monkey");
		String temp=null;
		return temp;
	
	}
	
	public String SVform(String subject,String verb,String tense)
	{
		SPhraseSpec p=nlgFactory.createClause();
		
		if(subject.endsWith("."))
		{	
			subject=subject.replace(".", " ");
			subject=subject.trim();
			
			p.setFeature(Feature.COMPLEMENTISER, "and");

			//p.addComplement(subject);
			p.setVerb(verb);
			String output;
			
	       if(verb.endsWith("."))
	       {
	    	   	output=verb;
	    	   	output=output.toLowerCase();
		        output=output.replace(".", " ");
				output=output.trim();
	       }
	       else
	       {
	       if(tense=="past")
	        	p.setFeature(Feature.TENSE, Tense.PAST);
	        else if(tense=="future")
	        	p.setFeature(Feature.TENSE, Tense.FUTURE);
	        else
	        	p.setFeature(Feature.TENSE, Tense.PRESENT);
			
			 output = realiser.realiseSentence(p);
	        
	        	output=output.toLowerCase();
	        	output=output.replace(".", " ");
				output=output.trim();
	       	}
			return subject + " and " + output;
		}
		
		//String[] sub=subject.split(" ");
		
		System.out.println("Subject in SV form is "+subject);
		
		p.setSubject(subject);
		p.setVerb(verb);
        if(tense=="past")
        	p.setFeature(Feature.TENSE, Tense.PAST);
        else if(tense=="future")
        	p.setFeature(Feature.TENSE, Tense.FUTURE);
        else
        	p.setFeature(Feature.TENSE, Tense.PRESENT);
        String output = realiser.realiseSentence(p);
        return output;
	}
	
	public String VOform(String verb,String object,String tense)
	{
		SPhraseSpec p = nlgFactory.createClause();
        p.setObject(object);
        p.setVerb(verb);
        
        if(tense=="past")
        	p.setFeature(Feature.TENSE, Tense.PAST);
        else if(tense=="future")
        	p.setFeature(Feature.TENSE, Tense.FUTURE);
        else
        	p.setFeature(Feature.TENSE, Tense.PRESENT);
        String output = realiser.realiseSentence(p);
        return output;
	}
	
	public String VAform(String verb,String tense,String adjective)
	{
		SPhraseSpec p = nlgFactory.createClause();
        p.setVerb(verb);
        p.addModifier(adjective);
        
        if(tense=="past")
        	p.setFeature(Feature.TENSE, Tense.PAST);
        else if(tense=="future")
        	p.setFeature(Feature.TENSE, Tense.FUTURE);
        else
        	p.setFeature(Feature.TENSE, Tense.PRESENT);
        String output = realiser.realiseSentence(p);
        return output;
	}
	public String SAform(String subject,String adjective)
	{
		SPhraseSpec p = nlgFactory.createClause();
        p.setSubject(subject);
        p.addModifier(adjective);
        
        String output = realiser.realiseSentence(p);
        return output;
	}
	
	private String SVformWithClause(String subject, String verb, String tense,
			String string) {
		return SVform(subject,verb,tense)+" "+string;
	}
	
	public String deconvert(UNLGraph intermediateGraph) {
		
	
		UNLNode node1=null,node2=null;
		String subject=null;String object=null;String verb=null;String tense=null;
		Relations relations[]=intermediateGraph.getRelations();
		UNLNode nodes[]=intermediateGraph.getNodes();
		String valid_tense="present";
		String output=null;
		
		for(int i=0;i<intermediateGraph.relation_count;i++)
		{
			if(intermediateGraph.relations[i].relation=="mod")
			{	
				String term1=nodes[intermediateGraph.relations[i].node1id].getRoot();
				String term2=nodes[intermediateGraph.relations[i].node2id].getRoot();
				System.out.println(intermediateGraph.relations[i].scopeID);
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=term1+" "+term2;
			}
			else if(intermediateGraph.relations[i].relation=="man")
			{	
				String term1=nodes[intermediateGraph.relations[i].node1id].getRoot();
				verb=nodes[intermediateGraph.relations[i].node2id].getRoot();
				tense=nodes[intermediateGraph.relations[i].node2id].getTense();
				System.out.println(intermediateGraph.relations[i].scopeID);
				intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=VAform(verb,tense,term1);
				
				System.out.println(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]);
			}
			else if(intermediateGraph.relations[i].relation=="agt")
			{	
				
				if(intermediateGraph.relations[i].isScope1==1)
				{	
					verb=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node1id];
					tense="present";
				}
				else
				{	
					verb=nodes[intermediateGraph.relations[i].node1id].getRoot();
					tense=nodes[intermediateGraph.relations[i].node1id].getTense();
				}
				
				if(intermediateGraph.relations[i].isScope2==1)
					subject=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node2id];
				else
				{	
					subject=nodes[intermediateGraph.relations[i].node2id].getRoot();
				}
				//System.out.println("tense is "+tense);
				
				if(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]==null)
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=SVform(subject,verb,tense);
				else
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=SVformWithClause(subject,verb,tense,intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]);
				
				System.out.println(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]);
			}
			else if(intermediateGraph.relations[i].relation=="obj")
			{	
				if(intermediateGraph.relations[i].isScope1==1)
				{	
					verb=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node1id];
					tense="present";
				}
				else
				{	
					verb=nodes[intermediateGraph.relations[i].node1id].getRoot();
					tense=nodes[intermediateGraph.relations[i].node1id].getTense();
				}
				
				if(intermediateGraph.relations[i].isScope2==1)
					object=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node2id];
				else
				{	
					object=nodes[intermediateGraph.relations[i].node2id].getRoot();
				}
				//System.out.println("tense is "+tense);
				
				if(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]==null)
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=VOform(verb,object,tense);
				else
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=SVformWithObject(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID],object);
				
				System.out.println(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]);
				
			}
			else if(intermediateGraph.relations[i].relation=="fmt")
			{	
				String term1,term2;
				if(intermediateGraph.relations[i].isScope1==1)
				{	
					term1=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node1id];
					tense="present";
				}
				else
				{	
					term1 =nodes[intermediateGraph.relations[i].node1id].getRoot();
					tense=nodes[intermediateGraph.relations[i].node1id].getTense();
				}
				
				if(intermediateGraph.relations[i].isScope2==1)
					term2=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node2id];
				else
				{	
					term2=nodes[intermediateGraph.relations[i].node2id].getRoot();
				}
				//System.out.println("tense is "+tense);
				
				if(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]==null)
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]="from "+term1+"to "+term2;
				else
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]+"from "+term1+"to "+term2;
				
				System.out.println(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]);
				
			}
			else if(intermediateGraph.relations[i].relation=="src")
			{	
				String term1,term2;
				if(intermediateGraph.relations[i].isScope1==1)
				{	
					term1=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node1id];
					tense="present";
				}
				else
				{	
					term1 =nodes[intermediateGraph.relations[i].node1id].getRoot();
					tense=nodes[intermediateGraph.relations[i].node1id].getTense();
				}
				
				
				
				if(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]==null)
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]="from "+term1;
				else
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]+"from "+term1;
				
				System.out.println(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]);
				
			}
			else if(intermediateGraph.relations[i].relation=="qua")
			{	
				String term1,term2;
				if(intermediateGraph.relations[i].isScope1==1)
				{	
					term1=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node1id];
					tense="present";
				}
				else
				{	
					term1 =nodes[intermediateGraph.relations[i].node1id].getRoot();
					tense=nodes[intermediateGraph.relations[i].node1id].getTense();
				}
				
				
				
				if(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]==null)
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]="measures of "+term1;
				else
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]+"measures of "+term1;
				
				System.out.println(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]);
				
			}
			else if(intermediateGraph.relations[i].relation=="dur")
			{	
				String term1,term2;
				if(intermediateGraph.relations[i].isScope1==1)
				{	
					term1=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node1id];
					tense="present";
				}
				else
				{	
					term1 =nodes[intermediateGraph.relations[i].node1id].getRoot();
					tense=nodes[intermediateGraph.relations[i].node1id].getTense();
				}
				
				if(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]==null)
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]="time" +term1;
				else
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]+" time "+term1;
				
				System.out.println(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]);
				
			}
			else if(intermediateGraph.relations[i].relation=="cnt")
			{	
				String term1,term2;
				if(intermediateGraph.relations[i].isScope1==1)
				{	
					term1=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node1id];
					tense="present";
				}
				else
				{	
					term1 =nodes[intermediateGraph.relations[i].node1id].getRoot();
					tense=nodes[intermediateGraph.relations[i].node1id].getTense();
				}
				
				if(intermediateGraph.relations[i].isScope2==1)
					term2=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node2id];
				else
				{	
					term2=nodes[intermediateGraph.relations[i].node2id].getRoot();
				}
				
				if(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]==null)
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=term1+" is a "+term2;
				else
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]+term1+" is a"+term2;
				
				System.out.println(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]);
				
			}
			else if(intermediateGraph.relations[i].relation=="and")
			{	
				String term1,term2;
				if(intermediateGraph.relations[i].isScope1==1)
				{	
					term1=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node1id];
					tense="present";
				}
				else
				{	
					term1 =nodes[intermediateGraph.relations[i].node1id].getRoot();
					tense=nodes[intermediateGraph.relations[i].node1id].getTense();
				}
				
				if(intermediateGraph.relations[i].isScope2==1)
					term2=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node2id];
				else
				{	
					term2=nodes[intermediateGraph.relations[i].node2id].getRoot();
				}
				
				if(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]==null)
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=term1+" and "+term2;
				else
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]+term1+" and "+term2;
				
				System.out.println(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]);
				
			}
			else if(intermediateGraph.relations[i].relation=="plf")
			{	
				String term1,term2;
				if(intermediateGraph.relations[i].isScope1==1)
				{	
					term1=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node1id];
					tense="present";
				}
				else
				{	
					term1 =nodes[intermediateGraph.relations[i].node1id].getRoot();
					tense=nodes[intermediateGraph.relations[i].node1id].getTense();
				}
			
				
				if(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]==null)
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]="from "+term1;
				else
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]+term1+" from "+term1;
				
				System.out.println(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]);
				
			}
			else if(intermediateGraph.relations[i].relation=="pof")
			{	
				String term1,term2;
				if(intermediateGraph.relations[i].isScope1==1)
				{	
					term1=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node1id];
					tense="present";
				}
				else
				{	
					term1 =nodes[intermediateGraph.relations[i].node1id].getRoot();
					tense=nodes[intermediateGraph.relations[i].node1id].getTense();
				}
				
				if(intermediateGraph.relations[i].isScope2==1)
					term2=intermediateGraph.resolvedScope[intermediateGraph.relations[i].node2id];
				else
				{	
					term2=nodes[intermediateGraph.relations[i].node2id].getRoot();
				}
				
				if(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]==null)
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=term1+"'s "+term2;
				else
					intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]=intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]+term1+"'s "+term2;
				
				System.out.println(intermediateGraph.resolvedScope[intermediateGraph.relations[i].scopeID]);
				
			}
			else if(intermediateGraph.relations[i].relation=="gol" || intermediateGraph.relations[i].relation=="ben")
			{
				subject=nodes[intermediateGraph.relations[i].node2id].getRoot();
				object="to "+nodes[intermediateGraph.relations[i].node2id].getRoot();
				tense=nodes[intermediateGraph.relations[i].node1id].getTense();
			}
			
			if(tense!=null)
				valid_tense=tense;
		}
		
		//String output=SVOform(subject,verb,object,valid_tense);
		//System.out.println(output);
		return output;
		
	}

	private String SVformWithObject(String string, String object) {
		
		string=string.replace('.', ' ');
		string=string.trim();
		
		SPhraseSpec p = nlgFactory.createClause(string.split(" ")[0],string.split(" ")[1]);
        p.setObject(object);
        
        System.out.println("subject is "+string);
        p.setFeature(Feature.PROGRESSIVE,1);
        String output = realiser.realiseSentence(p);
        System.out.println("output is "+output);
        return output;
	}

	

}
