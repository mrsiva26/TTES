package UNLEnCoverter;
import UNLWordFormat.*;
import analyser.SegmentedWord;

public class UNLEnConverter {
	
	public UNLNode UW[]=new UNLNode[120];
	public Relations relations[]=new Relations[120];
	int node_count=0,relation_count=0;
	static wordnetCommunicator wTranslator = new wordnetCommunicator();
	int recent_subject=-1;
	int recent_object=-1;
	
	public UNLGraph enconvert(SegmentedWord[] intermediateOutput) {
		
		UNLGraph temp=null;
		/*creating Universal Words */
		int current_scope=0;
		
	    for(int i=0;i<intermediateOutput.length;i++)
	    {
	    	String t=wTranslator.getEnglishWord(intermediateOutput[i].rootWord,intermediateOutput[i].POSId);
	    	
	    		
	    	System.out.println(intermediateOutput[i].rootWord+" -> "+t);
	    	
	    	UW[i]=new SimpleNode(t,node_count+1);
	    	if(wTranslator.IslastTermTransliterated()==1)
	    		UW[i].addAttribute("(icl>temp)");
	    	if(intermediateOutput[i].POSId==1 || intermediateOutput[i].POSId==2)

	    	{
	    		
	    		if(intermediateOutput[i].rootWord=="அவன்")
	    			UW[i].addAttribute("masculine");
	    		
	    		else if(intermediateOutput[i].rootWord=="அவள்")
	    			UW[i].addAttribute("feminine");
	    		

	    	}
	    	else if(intermediateOutput[i].POSId==4)
	    	{
	    		UW[i].addAttribute("adjective");
	    	}
	    	else if(intermediateOutput[i].POSId==5)
	    	{
	    		UW[i].addAttribute("adverb");
	    	} 
	    	else if(intermediateOutput[i].POSId==3)
	    	{
	    		/* since a simple sentence first verb is the entry*/
	    		System.out.println("found a verb at"+i);
	    		
	    		/*adding tense forms to UWs */
	    			
	    		if(intermediateOutput[i].tenseSuffixId==1 || intermediateOutput[i].tenseSuffixId==2 
	    					|| intermediateOutput[i].tenseSuffixId==3 || intermediateOutput[i].tenseSuffixId==4)
	    				UW[i].addAttribute("past");
	    		
	    			else if(intermediateOutput[i].tenseSuffixId==8 || intermediateOutput[i].tenseSuffixId==9)
	    				UW[i].addAttribute("future");
	    			
	    			else if(intermediateOutput[i].tenseSuffixId==5 || intermediateOutput[i].tenseSuffixId==6 || intermediateOutput[i].tenseSuffixId==7)
	    				UW[i].addAttribute("present");
	    		
	    	}
	    	node_count++;
	    }
	    
	    /*first pass - Check for hyper-nodes of type mod and con */
	    for(int i=0;i<intermediateOutput.length;i++)
	    {
	    	if(intermediateOutput[i].rootWord=="இருந்து" && intermediateOutput[i+2].rootWord=="வரை")
	    	{
	    		addRelation(i-1,i+1,"fmt",current_scope);
	    		UW[i-1].scopeID=current_scope;
	    		UW[i+1].scopeID=current_scope;
	    		reorder(i-1,4);
	    	}
	    	else if(intermediateOutput[i].rootWord=="இருந்து")
	    	{
	    		addRelation(0,i,"src",current_scope);
	    		UW[i].scopeID=current_scope;
	    		UW[i+1].scopeID=current_scope;
	    		reorder(i-1,2);
	    	}
	    	if(intermediateOutput[i].rootWord=="அல்லது")
	    	{
	    		/*reodering is done.Scope resolution needs to handled*/
	    		addRelation(i-1,i+1,"or",++current_scope);
	    		reorder(i,1);
	    	}
	    	else if(intermediateOutput[i].rootWord=="வழியாக")
	    	{
	    		/*reodering is done.Scope resolution needs to handled*/
	    		addRelation(i,i+1,"via",++current_scope);
	    		reorder(i,1);
	    	}
	    	else if(intermediateOutput[i].rootWord=="விட")
	    	{
	    		/*reodering is done.Scope resolution needs to handled*/
	    		addRelation(i-1,i+1,"bas",++current_scope);
	    		UW[i].scopeID=current_scope;
	    		UW[i+1].scopeID=current_scope;
	    		reorder(i,1);
	    	}
	    	else if(intermediateOutput[i].rootWord=="கிலோ" || intermediateOutput[i].rootWord=="கிராம்" )
	    	{
	    		addRelation(i-1,i+1,"qua",++current_scope);
	    		UW[i].scopeID=current_scope;
	    		UW[i+1].scopeID=current_scope;
	    		reorder(i,1);
	    	}
	    	if(intermediateOutput[i].rootWord=="என்பது" || intermediateOutput[i].rootWord=="எனப்படுவது" )
	    	{
	    		addRelation(i-1,i+1,"cnt",++current_scope);
	    		UW[i].scopeID=current_scope;
	    		UW[i+1].scopeID=current_scope;
	    		reorder(i,1);
	    	}
	    	if(intermediateOutput[i].nounSuffixId==2)
	    	{
	    		addRelation(i,i+1,"cnd",++current_scope);
	    		UW[i].scopeID=current_scope;
	    		UW[i+1].scopeID=current_scope;
	    		reorder(i,1);
	    	}
	    	if(intermediateOutput[i].rootWord=="நேரம்"||intermediateOutput[i].rootWord=="சமயம்"||intermediateOutput[i].rootWord=="மணி")
	    	{
	    		addRelation(i-1,i,"dur",current_scope);
	    		UW[i].scopeID=current_scope;
	    		reorder(i,1);
	    	}
	    	if(intermediateOutput[i].POSId==4)
	    	{
	    		addRelation(i,i+1,"mod",++current_scope);
	    		UW[i].scopeID=current_scope;
	    		UW[i+1].scopeID=current_scope;
	    		reorder(i,1);
	    	}
	    	else if(intermediateOutput[i].POSId==1 && intermediateOutput[i].nounSuffixId==4)
	    	{
	    		addRelation(i,i+1,"plc",++current_scope);
	    		UW[i].scopeID=current_scope;
	    		UW[i+1].scopeID=current_scope;
	    	}
	    	else if(intermediateOutput[i].POSId==1 && intermediateOutput[i].nounSuffixId==10)
	    	{
	    		addRelation(i,i+1,"con",++current_scope);
	    		UW[i].scopeID=current_scope;
	    		UW[i+1].scopeID=current_scope;
	    	}
	    	else if(intermediateOutput[i].POSId==5)
	    	{
	    		int found=0;
				for(int j=0;j<intermediateOutput.length;j++)
					if(intermediateOutput[j].POSId==3)
						{found=j;	break;}
	    		addRelation(i,found,"man",++current_scope);
	    		UW[i].scopeID=current_scope;
	    		UW[i+1].scopeID=current_scope;
	    		current_scope++;
	    	}
	    	
	    	
	    }
	    
	    
	    /*adding vinaietcham and peyaretcham relations to universal words*/ 
	    
	    for(int i=0;i<intermediateOutput.length;i++)
	    {
	    		    	
	    	if(intermediateOutput[i].POSId==1 && intermediateOutput[i].doerSuffixId==0)
	    	{   		
	    		addRelation(i,i+1,"agt",++current_scope);
	    		UW[i].scopeID=current_scope;
	    		UW[i+1].scopeID=current_scope;
	    		
	    		System.out.println("In hyper node relation with i as "+i);
	    		
	    		addRelation(i,i-1,"obj",current_scope);
	    		UW[i].scopeID=current_scope;
	    		UW[i+1].scopeID=current_scope;
	    		
	    	}
	    
	    }
	    
	    for(int i=0;i<intermediateOutput.length;i++)
	    {
	    	/*handling case for I - i makes a noun object*/
	    	if(intermediateOutput[i].POSId==1 || intermediateOutput[i].POSId==2)
	    	{
	    		switch(intermediateOutput[i].nounSuffixId)
	    		{
	    			case 1:
	    				int found=0;
	    				for(int j=0;j<intermediateOutput.length;j++)
	    					if(intermediateOutput[j].POSId==3)
	    						{found=j;	break;}
	    				addRelation(found,i,"obj",++current_scope);
	    				break;	
	    			case 4:
	    				addRelation(i,i+1,"pof",++current_scope);
	    				break;
	    				
	    			case 0:
	    				recent_subject=i;
	    				break;
	    		}
	    		
	    	}
	    	if(intermediateOutput[i].POSId==3)
	    	{	
	    		addRelation(i,recent_subject,"agt",++current_scope);
	    		current_scope++;
	    	}
	    	else if(intermediateOutput[i].POSId==5)
	    	{
	    		switch(intermediateOutput[i].nounSuffixId)
	    		{
	    			case 3:		
	    			addRelation(i,recent_subject,"plt",current_scope);	
	    				break;	
	    		}
	    	}
	    }
	    /*	else if(intermediateOutput[i].POSId==5)
	    	{
	    		switch(intermediateOutput[i].nounSuffixId)
	    		{

	    			case 3:
	    		    	
	    				if(first_noun!=-1)
	    				{	
	    					System.out.println(first_verb);
	    					relations[relation_count++]=new Relations(UW[first_verb],first_verb,UW[i],i,"gol");
	    				}		
	    				
	    				break;	
	    		}

	    	}
	    }

	    	}*/
	    System.out.println("Total number of relations is "+relation_count);
	    sort_UniversalWords();
	    temp=new UNLGraph(UW,relations,node_count,relation_count);
	    temp.printUNL();
	    return temp;
	}

	private void sort_UniversalWords() {
		
		UNLNode temp;
		for(int i=0;i<node_count;i++)
		{
			for(int j=i+1;j<node_count;j++)
			{
				if(UW[i].ID>UW[j].ID)
				{
					temp=UW[i];
					UW[i]=UW[j];
					UW[j]=temp;
				}
			}
		}
			
	}

	private void reorder(int i, int j) {
		int max=node_count;
		
		for(int k=i;k<i+j;k++)
		{
			UW[max++]=UW[k];
		}
		for(int k=i;k<node_count;k++)
		{
			UW[k]=UW[k+j];
		}
		System.out.println("After reordering");
		for(int k=0;k<node_count;k++)
		{
			System.out.print(UW[k].getRoot()+" ,");
		}
	
	}

	private void addRelation(int i, int found, String string, int j) {
		
		System.out.println("Adding "+string+" relation between "+UW[i].ID+"("+i+")->"+UW[i].type+" and "+UW[found].ID+"("+found+")->"+UW[i].type);
		if(UW[i].scopeID==0 && UW[found].scopeID==0)
		{
			relations[relation_count++]=new Relations(UW[i],UW[i].ID,UW[found],UW[found].ID,string,j);
		}
		else if(UW[i].scopeID==1 && UW[found].scopeID==0)
		{
			relations[relation_count++]=new Relations(UW[i].scopeID,UW[found],UW[found].ID,string,j);
		}
		else if(UW[i].scopeID==0)
		{
			relations[relation_count++]=new Relations(UW[i],UW[i].ID,UW[found].scopeID,string,j);
		}
		else
			relations[relation_count++]=new Relations(UW[i].scopeID,UW[found].scopeID,string,j);
		
	}
}
