package UNLEnCoverter;
import UNLWordFormat.*;
import UNLDeConverter.UNLDeConverter;

import analyser.SegmentedWord;
public class UNLEnConverterUNITTEST {

	static UNLEnConverter converter=new UNLEnConverter();
	static UNLDeConverter decon=new UNLDeConverter();
	static SegmentedWord seg[] = new SegmentedWord[6];
	public static void main(String[] args) {

		UNLGraph tempGraph;
		
		/*SegmentedWord seg_temp =new SegmentedWord();
		seg_temp.rootWord="நான்";
		seg_temp.POSId=1;
		seg_temp.nounSuffixId=0;
		seg[0]=(seg_temp);
		
		SegmentedWord seg_temp1 =new SegmentedWord();
		seg_temp1.rootWord="அழகிய";
		seg_temp1.POSId=4;
		seg[1]=(seg_temp1);
		
		SegmentedWord seg_temp2 =new SegmentedWord();
		seg_temp2.rootWord="பூங்கா";
		seg_temp2.POSId=1;
		seg_temp2.nounSuffixId=1;
		seg[2]=(seg_temp2);
		

		SegmentedWord seg_temp3 =new SegmentedWord();
		seg_temp3.rootWord="காண்";
		seg_temp3.POSId=3;
		seg_temp3.tenseSuffixId=10;
		seg[3]=(seg_temp3);
		*/
		
		/*SegmentedWord seg_temp =new SegmentedWord();
		seg_temp.rootWord="நான்";
		seg_temp.POSId=1;
		seg_temp.nounSuffixId=0;
		seg[0]=(seg_temp);
		
		SegmentedWord seg_temp2 =new SegmentedWord();
		seg_temp2.rootWord="பூங்கா";
		seg_temp2.POSId=1;
		seg_temp2.nounSuffixId=1;
		seg[1]=(seg_temp2);
		

		SegmentedWord seg_temp3 =new SegmentedWord();
		seg_temp3.rootWord="காண்";
		seg_temp3.POSId=3;
		seg_temp3.tenseSuffixId=10;
		seg[2]=(seg_temp3);*/
				
		/*SegmentedWord seg_temp =new SegmentedWord();
		seg_temp.rootWord="நான்";
		seg_temp.POSId=2;
		seg_temp.nounSuffixId=0;
		seg[0]=(seg_temp);
		
		SegmentedWord seg_temp2 =new SegmentedWord();
		seg_temp2.rootWord="வேகம்";
		seg_temp2.POSId=5;
		seg_temp2.nounSuffixId=1;
		seg[1]=(seg_temp2);
		

		SegmentedWord seg_temp3 =new SegmentedWord();
		seg_temp3.rootWord="ஒடு";
		seg_temp3.POSId=3;
		seg_temp3.tenseSuffixId=10;
		seg[2]=(seg_temp3);
		*/
		
		/*SegmentedWord seg_temp =new SegmentedWord();
		seg_temp.rootWord="சீதை";
		seg_temp.POSId=0;
		seg_temp.nounSuffixId=1;
		seg[0]=(seg_temp);
		
		SegmentedWord seg_temp1 =new SegmentedWord();
		seg_temp1.rootWord="கண்ட";
		seg_temp1.POSId=1;
		seg_temp1.doerSuffixId=0;
		seg[1]=(seg_temp1);
		
		SegmentedWord seg_temp2 =new SegmentedWord();
		seg_temp2.rootWord="இராமன்";
		seg_temp2.POSId=1;
		seg_temp2.nounSuffixId=0;
		seg[2]=(seg_temp2);
		
		

		SegmentedWord seg_temp3 =new SegmentedWord();
		seg_temp3.rootWord="அழு";
		seg_temp3.POSId=3;
		seg_temp3.tenseSuffixId=10;
		seg[3]=(seg_temp3);
		*/
		/*
		SegmentedWord seg_temp0 =new SegmentedWord();
		seg_temp0.rootWord="அழகிய";
		seg_temp0.POSId=4;
		seg[0]=(seg_temp0);
		
		SegmentedWord seg_temp =new SegmentedWord();
		seg_temp.rootWord="சீதை";
		seg_temp.POSId=0;
		seg_temp.nounSuffixId=1;
		seg[1]=(seg_temp);
		
		SegmentedWord seg_temp1 =new SegmentedWord();
		seg_temp1.rootWord="கண்ட";
		seg_temp1.POSId=1;
		seg_temp1.doerSuffixId=0;
		seg[2]=(seg_temp1);
		
		SegmentedWord seg_temp2 =new SegmentedWord();
		seg_temp2.rootWord="இராமன்";
		seg_temp2.POSId=1;
		seg_temp2.nounSuffixId=0;
		seg[3]=(seg_temp2);
		
		
		SegmentedWord seg_temp3 =new SegmentedWord();
		seg_temp3.rootWord="அழு";
		seg_temp3.POSId=3;
		seg_temp3.tenseSuffixId=10;
		seg[4]=(seg_temp3);
		*/
		/*
		SegmentedWord seg_temp0 =new SegmentedWord();
		seg_temp0.rootWord="அழகிய";
		seg_temp0.POSId=4;
		seg[0]=(seg_temp0);
		
		SegmentedWord seg_temp =new SegmentedWord();
		seg_temp.rootWord="சீதை";
		seg_temp.POSId=0;
		seg_temp.nounSuffixId=1;
		seg[1]=(seg_temp);
		
		SegmentedWord seg_temp1 =new SegmentedWord();
		seg_temp1.rootWord="கண்ட";
		seg_temp1.POSId=1;
		seg_temp1.doerSuffixId=0;
		seg[2]=(seg_temp1);
		
		SegmentedWord seg_temp2 =new SegmentedWord();
		seg_temp2.rootWord="இராமன்";
		seg_temp2.POSId=1;
		seg_temp2.nounSuffixId=0;
		seg[3]=(seg_temp2);
		
		SegmentedWord seg_temp5 =new SegmentedWord();
		seg_temp5.rootWord="வேகம்";
		seg_temp5.POSId=5;
		seg_temp5.nounSuffixId=1;
		seg[4]=(seg_temp5);
		
		
		SegmentedWord seg_temp3 =new SegmentedWord();
		seg_temp3.rootWord="ஒடு";
		seg_temp3.POSId=3;
		seg_temp3.tenseSuffixId=10;
		seg[5]=(seg_temp3);
		*/
		
		SegmentedWord seg_temp0 =new SegmentedWord();
		seg_temp0.rootWord="அழகிய";
		seg_temp0.POSId=4;
		seg[0]=(seg_temp0);
		
		SegmentedWord seg_temp =new SegmentedWord();
		seg_temp.rootWord="சீதை";
		seg_temp.POSId=0;
		seg_temp.nounSuffixId=1;
		seg[1]=(seg_temp);
		
		SegmentedWord seg_temp1 =new SegmentedWord();
		seg_temp1.rootWord="கண்ட";
		seg_temp1.POSId=1;
		seg_temp1.doerSuffixId=0;
		seg[2]=(seg_temp1);
		
		SegmentedWord seg_temp2 =new SegmentedWord();
		seg_temp2.rootWord="இராமன்";
		seg_temp2.POSId=1;
		seg_temp2.nounSuffixId=0;
		seg[3]=(seg_temp2);
		
		SegmentedWord seg_temp5 =new SegmentedWord();
		seg_temp5.rootWord="வேகம்";
		seg_temp5.POSId=5;
		seg_temp5.nounSuffixId=1;
		seg[4]=(seg_temp5);
		
		
		SegmentedWord seg_temp3 =new SegmentedWord();
		seg_temp3.rootWord="ஒடு";
		seg_temp3.POSId=3;
		seg_temp3.tenseSuffixId=10;
		seg[5]=(seg_temp3);
		tempGraph=converter.enconvert(seg);
		//tempGraph.printUNL();
		decon.deconvert(tempGraph);

	}

}
