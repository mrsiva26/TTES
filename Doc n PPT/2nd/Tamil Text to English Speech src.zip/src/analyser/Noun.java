package analyser;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Noun {
	static String inflectednoun;
	public static String root;
	static SegmentedWord sw;

	private static int getnoofஎழுத்து(String str){
		ArrayList<String> characters=new ArrayList<String>();
		Pattern pat=Pattern.compile("\\p{L}\\p{M}*");
		Matcher matcher=pat.matcher(str);
		while(matcher.find())
		{
			characters.add(matcher.group());
		}
		return characters.size();
	}
	/**
	 * @param s
	 * @return
	 */
	public static SegmentedWord analyse(String s){
		inflectednoun=s;
		sw = new SegmentedWord();
		sw.POS = "object";
		sw.POSId = 1;
		Pattern pat;
		Matcher matcher;
		Nedil ned = new Nedil();



		//type=1;
		pat = Pattern.compile("(லை|லால்|லுக்கு|லில்|லின்|லினது|ற்கள்|ற்களால்|லின்கண்)$");
		matcher = pat.matcher(inflectednoun); 
		if(matcher.find()){
			String[] splitString = inflectednoun.split("லை|லால்|லுக்கு|லில்|லின்|லினது|ற்கள்|ற்களால்|லின்கண்");
			root = splitString[0];
			String tempSuffix = inflectednoun.replace(splitString[0], "");
			System.out.println("\n"+root + "\t"+getnoofஎழுத்து(root)+"\t" + tempSuffix);

			if(ned.isNedil(root)==true){
				//{"காலை","காலால்","காலுக்கு","காலில்","காலின்","காலினது","காலின்கண்"};
				System.out.println("IamNedil");
				root = root+"ல்";
				switch(tempSuffix){
				case "லை": sw.nounSuffix="ஐ"; sw.nounSuffixId=1;
				break;
				case "லால்": sw.nounSuffix="ஆல்"; sw.nounSuffixId=2;
				break;
				case "லுக்கு": sw.nounSuffix="கு"; sw.nounSuffixId=3;
				break;
				case "லில்": sw.nounSuffix="இல்"; sw.nounSuffixId=4;
				break;
				case "லின்": sw.nounSuffix="இன்"; sw.nounSuffixId=5;
				break;
				case "லினது": sw.nounSuffix="அது"; sw.nounSuffixId=6;
				break;
				/*case "கள்": sw.nounSuffix="கள்"; sw.nounSuffixId=7;
				break;
				case "களால்": sw.nounSuffix="களால்"; sw.nounSuffixId=8;
				break;*/
				case "லின்கண்": sw.nounSuffix="கண்"; sw.nounSuffixId=9;
				break;
				default: System.out.println("Exception from காலை, காலால், காலுக்கு, காலில், காலின், காலினது, காலின்கண்");
				}
				sw.rootWord=root;
				System.out.println("Print from காலை, காலால், காலுக்கு, காலில், காலின், காலினது, காலின்கண்" +"\n"+ inflectednoun +"\n"+ "POS :"+sw.POS +"\n"+ "POSid :"+sw.POSId +"\n"+ "rootword: "+sw.rootWord +"\n"+ "NounSuffix :"+sw.nounSuffix +"\n"+ "NounSuffixid :"+sw.nounSuffixId);
				return sw;	
			}else if(getnoofஎழுத்து(root)==2){
				//{"சொல்லை","சொல்லால்","சொல்லுக்கு","சொல்லின்","சொல்லில்","சொல்லினது","சொல்ல்ங்கண்","சொற்கள்"}
				System.out.println("IamNotNedil");
				switch(tempSuffix){
				case "லை": sw.nounSuffix="ஐ"; sw.nounSuffixId=1;
				break;
				case "லால்": sw.nounSuffix="ஆல்"; sw.nounSuffixId=2;
				break;
				case "லுக்கு": sw.nounSuffix="கு"; sw.nounSuffixId=3;
				break;
				case "லில்": sw.nounSuffix="இல்"; sw.nounSuffixId=4;
				break;
				case "லின்": sw.nounSuffix="இன்"; sw.nounSuffixId=5;
				break;
				case "லினது": sw.nounSuffix="அது"; sw.nounSuffixId=6;
				break;
				case "ற்கள்": root = root + "ல்"; sw.nounSuffix="கள்"; sw.nounSuffixId=7;
				break;
				case "ற்களால்": root = root + "ல்"; sw.nounSuffix="களால்"; sw.nounSuffixId=8;
				break;
				case "லின்கண்": sw.nounSuffix="கண்"; sw.nounSuffixId=9;
				break;
				default: System.out.println("Exception from சொல்லை, சொல்லால், சொல்லுக்கு, சொல்லின், சொல்லில், சொல்லினது, சொல்ல்ங்கண், சொற்கள்");
				}
				sw.rootWord=root;
				System.out.println("Print from சொல்லை, சொல்லால், சொல்லுக்கு, சொல்லின், சொல்லில், சொல்லினது, சொல்ல்ங்கண், சொற்கள்" +"\n"+ inflectednoun +"\n"+ "POS :"+sw.POS +"\n"+ "POSid :"+sw.POSId +"\n"+ "rootword: "+sw.rootWord +"\n"+ "NounSuffix :"+sw.nounSuffix +"\n"+ "NounSuffixid :"+sw.nounSuffixId);
				return sw;	
			}else{
				//{"கப்பலை","கப்பலால்","கப்பலுக்கு","கப்பலின்","கப்பலில்","கப்பலினது","கப்பலிங்கண்"};
				root = root + "ல்";
				switch(tempSuffix){
				case "லை": sw.nounSuffix="ஐ"; sw.nounSuffixId=1;
				break;
				case "லால்": sw.nounSuffix="ஆல்"; sw.nounSuffixId=2;
				break;
				case "லுக்கு": sw.nounSuffix="கு"; sw.nounSuffixId=3;
				break;
				case "லில்": sw.nounSuffix="இல்"; sw.nounSuffixId=4;
				break;
				case "லின்": sw.nounSuffix="இன்"; sw.nounSuffixId=5;
				break;
				case "லினது": sw.nounSuffix="அது"; sw.nounSuffixId=6;
				break;
				/*case "கள்": sw.nounSuffix="கள்"; sw.nounSuffixId=7;
				break;
				case "களால்": sw.nounSuffix="களால்"; sw.nounSuffixId=8;
				break;*/
				case "லின்கண்": sw.nounSuffix="கண்"; sw.nounSuffixId=9;
				break;
				default: System.out.println("Exception from கப்பலை, கப்பலால், கப்பலுக்கு, கப்பலின், கப்பலில், கப்பலினது, கப்பலிங்கண்");
				}
				sw.rootWord=root;
				System.out.println("Print from கப்பலை, கப்பலால், கப்பலுக்கு, கப்பலின், கப்பலில், கப்பலினது, கப்பலிங்கண்" +"\n"+ inflectednoun +"\n"+ "POS :"+sw.POS +"\n"+ "POSid :"+sw.POSId +"\n"+ "rootword: "+sw.rootWord +"\n"+ "NounSuffix :"+sw.nounSuffix +"\n"+ "NounSuffixid :"+sw.nounSuffixId);
				return sw;				
			}
		}

		//type=4;
		pat = Pattern.compile("(பை|பால்|புக்கு|பிற்கு|பில்|பின்|பினது|புகள்|புகளால்|பின்கண்)$");
		matcher = pat.matcher(inflectednoun); 
		if(matcher.find()){
			String[] splitString = inflectednoun.split("(பை|பால்|க்கு|பிற்கு|பில்|பின்|பினது|கள்|களால்|பின்கண்)$");

			root = splitString[0];

			String tempSuffix = inflectednoun.replace(splitString[0], "");
			System.out.println("\n"+root + "\t"+getnoofஎழுத்து(root)+"\t" + tempSuffix);
			switch(tempSuffix){
			case "பை": sw.nounSuffix="ஐ"; sw.nounSuffixId=1; root+="பு";
			break;
			case "பால்": sw.nounSuffix="ஆல்"; sw.nounSuffixId=2; root+="பு";
			break;
			case "க்கு": sw.nounSuffix="கு"; sw.nounSuffixId=3;
			break;
			case "பிற்கு": sw.nounSuffix="கு"; sw.nounSuffixId=3; root+="பு";
			break;
			case "பில்": sw.nounSuffix="இல்"; sw.nounSuffixId=4; root+="பு";
			break;
			case "பின்": sw.nounSuffix="இன்"; sw.nounSuffixId=5; root+="பு";
			break;
			case "பினது": sw.nounSuffix="அது"; sw.nounSuffixId=6; root+="பு";
			break;
			case "கள்": sw.nounSuffix="கள்"; sw.nounSuffixId=7;
			break;
			case "களால்": sw.nounSuffix="களால்"; sw.nounSuffixId=8;
			break;
			case "பின்கண்": sw.nounSuffix="கண்"; sw.nounSuffixId=9; root+="பு";
			break;
			default: System.out.println("Exception from பை|பால்|புக்கு|பிற்கு|பில்|பின்|பினது|புகள்|புகளால்|பின்கண் switch");
			}
			sw.rootWord=root;
			System.out.println(inflectednoun +"\n"+ "POS :"+sw.POS +"\n"+ "POSid :"+sw.POSId +"\n"+ "rootword: "+sw.rootWord +"\n"+ "NounSuffix :"+sw.nounSuffix +"\n"+ "NounSuffixid :"+sw.nounSuffixId);
			return sw;
		}

		//type=5;
		pat = Pattern.compile("(ட்டை|ட்டால்|ட்டுக்கு|ட்டிற்கு|ட்டில்|ட்டின்|ட்டினது|டுகள்|டுகளால்|ட்டின்கண்)$");
		matcher = pat.matcher(inflectednoun); 
		if(matcher.find()){
			String[] splitString = inflectednoun.split("(ட்டை|ட்டால்|ட்டுக்கு|ட்டிற்கு|ட்டில்|ட்டின்|ட்டினது|கள்|களால்|ட்டின்கண்)$");
			root = splitString[0];

			String tempSuffix = inflectednoun.replace(splitString[0], "");
			System.out.println("\n"+root + "\t"+getnoofஎழுத்து(root)+"\t" + tempSuffix);
			switch(tempSuffix){
			case "ட்டை": sw.nounSuffix="ஐ"; sw.nounSuffixId=1; root+="டு";
			break;
			case "ட்டால்": sw.nounSuffix="ஆல்"; sw.nounSuffixId=2; root+="டு";
			break;
			case "ட்டுக்கு": sw.nounSuffix="கு"; sw.nounSuffixId=3; root+="டு";
			break;
			case "ட்டிற்கு": sw.nounSuffix="கு"; sw.nounSuffixId=3; root+="டு";
			break;
			case "ட்டில்": sw.nounSuffix="இல்"; sw.nounSuffixId=4; root+="டு";
			break;
			case "ட்டின்": sw.nounSuffix="இன்"; sw.nounSuffixId=5; root+="டு";
			break;
			case "ட்டினது": sw.nounSuffix="அது"; sw.nounSuffixId=6; root+="டு";
			break;
			case "கள்": sw.nounSuffix="கள்"; sw.nounSuffixId=7;
			break;
			case "களால்": sw.nounSuffix="களால்"; sw.nounSuffixId=8;
			break;
			case "ட்டின்கண்": sw.nounSuffix="கண்"; sw.nounSuffixId=9; root+="டு";
			break;
			default: System.out.println("Exception from ட்டை|ட்டால்|ட்டுக்கு|ட்டிற்கு|ட்டில்|ட்டின்|ட்டினது|கள்|களால்|ட்டின்கண் switch");
			}
			sw.rootWord=root;
			System.out.println(inflectednoun +"\n"+ "POS :"+sw.POS +"\n"+ "POSid :"+sw.POSId +"\n"+ "rootword: "+sw.rootWord +"\n"+ "NounSuffix :"+sw.nounSuffix +"\n"+ "NounSuffixid :"+sw.nounSuffixId);
			return sw;
		}


		//type=2;
		pat = Pattern.compile("(கை|கால்|கிற்கு|குக்கு|கில்|கின்|கினது|கள்|களால்|கின்கண்)$");
		matcher = pat.matcher(inflectednoun); 
		if(matcher.find()){
			String[] splitString = inflectednoun.split("(கை|கால்|க்கு|கிற்கு|கில்|கின்|கினது|கள்|களால்|கின்கண்)$");

			root = splitString[0];

			String tempSuffix = inflectednoun.replace(splitString[0], "");
			System.out.println("\n"+root + "\t"+getnoofஎழுத்து(root)+"\t" + tempSuffix);
			switch(tempSuffix){
			case "கை": sw.nounSuffix="ஐ"; sw.nounSuffixId=1; root+="கு";
			break;
			case "கால்": sw.nounSuffix="ஆல்"; sw.nounSuffixId=2; root+="கு";
			break;
			case "க்கு": sw.nounSuffix="கு"; sw.nounSuffixId=3;
			break;
			case "கிற்கு": sw.nounSuffix="கு"; sw.nounSuffixId=3; root+="கு";
			break;
			case "கில்": sw.nounSuffix="இல்"; sw.nounSuffixId=4; root+="கு";
			break;
			case "கின்": sw.nounSuffix="இன்"; sw.nounSuffixId=5; root+="கு";
			break;
			case "கினது": sw.nounSuffix="அது"; sw.nounSuffixId=6; root+="கு";
			break;
			case "கள்": sw.nounSuffix="கள்"; sw.nounSuffixId=7;
			break;
			case "களால்": sw.nounSuffix="களால்"; sw.nounSuffixId=8;
			break;
			case "கின்கண்": sw.nounSuffix="கண்"; sw.nounSuffixId=9; root+="கு";
			break;
			default: System.out.println("Exception from கை|கால்|க்கு|கில்|கின்|கினது|கள்|களால்|கின்கண் switch");
			}
			sw.rootWord=root;
			System.out.println(inflectednoun +"\n"+ "POS :"+sw.POS +"\n"+ "POSid :"+sw.POSId +"\n"+ "rootword: "+sw.rootWord +"\n"+ "NounSuffix :"+sw.nounSuffix +"\n"+ "NounSuffixid :"+sw.nounSuffixId);
			return sw;
		}


		//type=0;
		pat = Pattern.compile("(யை|யால்|க்கு|யில்|யின்|யினது|யின்கண்)$");
		matcher = pat.matcher(inflectednoun);        
		if(matcher.find()){
			String[] splitString = inflectednoun.split("யை|யால்|க்கு|யில்|யின்|யினது|கள்|களால்|யின்கண்");
			root = splitString[0];
			String tempSuffix = inflectednoun.replace(splitString[0], "");
			System.out.println("\n"+root + "\t"+getnoofஎழுத்து(root)+"\t" + tempSuffix);
			if(ned.isNedil(root)==true){
				System.out.println("\tIamNedil\t");
				switch(tempSuffix){
				case "யை": root = root + "ய்"; sw.nounSuffix="ஐ"; sw.nounSuffixId=1;
				break;
				case "யால்": root = root + "ய்"; sw.nounSuffix="ஆல்"; sw.nounSuffixId=2;
				break;
				//பேய் + க்கு - SO root is no longer a nedil. It will be handled by next Switch case
				/*case "க்கு": sw.nounSuffix="கு"; sw.nounSuffixId=3;
				break;*/
				case "யில்": root = root + "ய்"; sw.nounSuffix="இல்"; sw.nounSuffixId=4;
				break;
				case "யின்": root = root + "ய்"; sw.nounSuffix="இன்"; sw.nounSuffixId=5;
				break;
				case "யினது": root = root + "ய்"; sw.nounSuffix="அது"; sw.nounSuffixId=6;
				break;
				//YETTOHANDLE
				/*
				case "கள்": sw.nounSuffix="கள்"; sw.nounSuffixId=7;
				break;
				case "களால்": sw.nounSuffix="களால்"; sw.nounSuffixId=8;
				break;
				 */
				case "யின்கண்": root = root + "ய்"; sw.nounSuffix="கண்"; sw.nounSuffixId=9;
				break;
				default: System.out.println("Exception from யை|யால்|க்கு|யில்|யின்|யினது|கள்|களால்|யின்கண்  Nedil");
				}
				sw.rootWord=root;
				System.out.println(inflectednoun +"\n"+ "POS :"+sw.POS +"\n"+ "POSid :"+sw.POSId +"\n"+ "rootword: "+sw.rootWord +"\n"+ "NounSuffix :"+sw.nounSuffix +"\n"+ "NounSuffixid :"+sw.nounSuffixId);
				return sw;
			}
			sw.rootWord=root;
			switch(tempSuffix){
			case "யை": sw.nounSuffix="ஐ"; sw.nounSuffixId=1;
			break;
			case "யால்": sw.nounSuffix="ஆல்"; sw.nounSuffixId=2;
			break;
			case "க்கு": sw.nounSuffix="கு"; sw.nounSuffixId=3;
			break;
			case "யில்": sw.nounSuffix="இல்"; sw.nounSuffixId=4;
			break;
			case "யின்": sw.nounSuffix="இன்"; sw.nounSuffixId=5;
			break;
			case "யினது": sw.nounSuffix="அது"; sw.nounSuffixId=6;
			break;
			case "கள்": sw.nounSuffix="கள்"; sw.nounSuffixId=7;
			break;
			case "களால்": sw.nounSuffix="களால்"; sw.nounSuffixId=8;
			break;
			case "யின்கண்": sw.nounSuffix="கண்"; sw.nounSuffixId=9;
			break;
			default: System.out.println("Exception from யை|யால்|க்கு|யில்|யின்|யினது|கள்|களால்|யின்கண்  switch");
			}
			System.out.println(inflectednoun +"\n"+ "POS :"+sw.POS +"\n"+ "POSid :"+sw.POSId +"\n"+ "rootword: "+sw.rootWord +"\n"+ "NounSuffix :"+sw.nounSuffix +"\n"+ "NounSuffixid :"+sw.nounSuffixId);
			return sw;
		}


		//type=3;
		pat = Pattern.compile("(த்தை|த்தால்|த்துக்கு|த்தில்|த்தின்|த்தினது|த்தின்கண்)$");
		matcher = pat.matcher(inflectednoun); 
		if(matcher.find()){
			String[] splitString = inflectednoun.split("த்தை|த்தால்|த்துக்கு|த்தில்|த்தின்|த்தினது|கள்|களால்|த்தின்கண்");
			if(splitString[0].endsWith("ங்")){
				root = splitString[0].substring(0, splitString[0].length()-2) + "ம்";
			}else{
				root = splitString[0] + "ம்";
			}
			String tempSuffix = inflectednoun.replace(splitString[0], "");
			System.out.println("\n"+root + "\t"+getnoofஎழுத்து(root)+"\t" + tempSuffix);
			sw.rootWord=root;
			switch(tempSuffix){
			case "த்தை": sw.nounSuffix="ஐ"; sw.nounSuffixId=1;
			break;
			case "த்தால்": sw.nounSuffix="ஆல்"; sw.nounSuffixId=2;
			break;
			case "த்துக்கு": sw.nounSuffix="கு"; sw.nounSuffixId=3;
			break;
			case "த்தில்": sw.nounSuffix="இல்"; sw.nounSuffixId=4;
			break;
			case "த்தின்": sw.nounSuffix="இன்"; sw.nounSuffixId=5;
			break;
			case "த்தினது": sw.nounSuffix="அது"; sw.nounSuffixId=6;
			break;
			case "கள்": sw.nounSuffix="கள்"; sw.nounSuffixId=7;
			break;
			case "களால்": sw.nounSuffix="களால்"; sw.nounSuffixId=8;
			break;
			case "த்தின்கண்": sw.nounSuffix="கண்"; sw.nounSuffixId=9;
			break;
			default: System.out.println("Exception from த்தை|த்தால்|த்துக்கு|த்தில்|த்தின்|த்தினது|கள்|களால்|த்தின்கண் switch");
			}
			System.out.println(inflectednoun +"\n"+ "POS :"+sw.POS +"\n"+ "POSid :"+sw.POSId +"\n"+ "rootword: "+sw.rootWord +"\n"+ "NounSuffix :"+sw.nounSuffix +"\n"+ "NounSuffixid :"+sw.nounSuffixId);
			return sw;
		}


		return sw;
	}

	public static void main(String args[]){
		String test[] = 

		{"ஓட்டை","ஓட்டால்","ஓட்டுக்கு","ஓட்டிற்கு","சாப்பாட்டில்","வீட்டின்","வீட்டினது","வீடுகள்","மேடுகளால்","மேட்டின்கண்"};				
		//{"தோப்பை","சீப்பால்","தோப்புக்கு","தோப்பிற்கு","தோப்பில்","சீப்பின்","சீப்பினது","தோப்புகள்","தோப்புகளால்","தோப்பின்கண்"};
		//{"நாக்கை","நாக்கால்","நாக்குக்கு","நாக்கிற்கு","நாக்கில்","நாக்கின்","நாக்கினது","சாக்குகள்","சாக்குகளால்","நாக்கின்கண்"}; 
		//{"காலை","காலால்","காலுக்கு","காலில்","காலின்","காலினது","காலின்கண்"};
		//{"சொல்லை","சொல்லால்","சொல்லுக்கு","சொல்லின்","சொல்லில்","சொல்லினது","சொல்ல்ங்கண்","சொற்கள்"};
		//{"கப்பலை","கப்பலால்","கப்பலுக்கு","கப்பலின்","கப்பலில்","கப்பலினது","கப்பலிங்கண்"};

		//{"வடையை","வடையால்","வடைக்கு","வடையின்","வடையில்","வடையினது","வடையின்கண்"};
		//{"பேயை","பேயால்","பேய்க்கு","பேயின்","பேயில்","பேயினது","பேயிங்கண்"};


		for(String s:test){
			Noun.analyse(s);
		}
	}
}
