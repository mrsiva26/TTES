package analyser;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class analyser {
	public SegmentedWord[] analyzeText(String input)
	{
		String words[] = input.replaceAll("\\s+", " ").split(" ");
		for(int i=0;i<words.length;i++)
			System.out.println(words[i]);

		SegmentedWord IntermediateOutput[] = new SegmentedWord[words.length];
		Pattern pat;
		Matcher matcher;	
		for(int i=0;i<words.length;i++){
			IntermediateOutput[i] = new SegmentedWord();
			IntermediateOutput[i].inflectedWord=words[i];

			//இயல்பினும் விதியினும் நின்ற உயிர் முன் கசதப மிகும்
			pat = Pattern.compile("(க்|ச்|த்|ப்)$");
			matcher = pat.matcher(words[i]);    
			if(matcher.find()){
				pat = Pattern.compile("(க|ச|த|ப).*");
				matcher = pat.matcher(words[i+1]);
				if(matcher.find()){
					words[i] = words[i].substring(0, words[i].length()-2);
				}
			}

			//வினைமுற்று விகுதிகள்
			pat = Pattern.compile("(தேன்|தாய்|தீர்|தீர்கள்|தான்|தாள்|தார்|தார்கள்|தனர்|தோம்|தது|தன|டான்|டாய்|டீர்|டீர்கள்|டான்|டாள்|டார்|டார்கள்|டனர்|டோம்|டது|டன|டது|றான்|றாய்|றீர்|றீர்கள்|றான்|றாள்|றார்|றார்கள்|றனர்|றோம்|றது|றன|றது|கிறேன்|கிறோம்|கிறாய்|கிறீர்கள்|கிறான்|கிறாள்|கிறார்கள்|கிறார்|கிறன|கிறது|கின்றேன்|கின்றோம்|கின்றாய்|கின்றீர்கள்|கின்றான்|கின்றாள்|கின்றார்கள்|கின்றார்|கின்றன|கின்றது|ப்பேன்|ப்பாய்|ப்பீர்|ப்பீர்கள்|ப்பான்|ப்பாள்|ப்பார்|ப்பார்கள்|ப்பனர்|ப்போம்|ப்பது|ப்பன|வேன்|வாய்|வீர்|வீர்கள்|வான்|வாள்|வார்|வார்கள்|வனர்|வோம்|வது|வன)$");
			matcher = pat.matcher(words[i]);    
			if(matcher.find()){
				IntermediateOutput[i] = Verb.analyse(words[i]);
				IntermediateOutput[i].inflectedWord=words[i];
				checkDB(IntermediateOutput[i]);
				continue;
			}

			//pronoun
			boolean pronoun=false;
			switch(words[i]){
			case "நான்": 
				pronoun=true;
				IntermediateOutput[i].rootWord="நான்";
				IntermediateOutput[i].POS="pronoun";
				IntermediateOutput[i].POSId=2;
				IntermediateOutput[i].doerSuffix="ஏன்";
				IntermediateOutput[i].doerSuffixId=1;
				System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord +"\n"+ "DoerSuffix :"+IntermediateOutput[i].doerSuffix +"\n"+ "DoerSuffixid :"+IntermediateOutput[i].doerSuffixId);
				break;
			case "நாம்":
				pronoun=true;
				IntermediateOutput[i].rootWord="நாம்";
				IntermediateOutput[i].POS="pronoun";
				IntermediateOutput[i].POSId=2;
				IntermediateOutput[i].doerSuffix="ஓம்";
				IntermediateOutput[i].doerSuffixId=2;
				System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord +"\n"+ "DoerSuffix :"+IntermediateOutput[i].doerSuffix +"\n"+ "DoerSuffixid :"+IntermediateOutput[i].doerSuffixId);
				break;
			case "நாங்கள்":
				pronoun=true;
				IntermediateOutput[i].rootWord="நாங்கள்";
				IntermediateOutput[i].POS="pronoun";
				IntermediateOutput[i].POSId=2;
				IntermediateOutput[i].doerSuffix="ஓம்";
				IntermediateOutput[i].doerSuffixId=2;
				System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord +"\n"+ "DoerSuffix :"+IntermediateOutput[i].doerSuffix +"\n"+ "DoerSuffixid :"+IntermediateOutput[i].doerSuffixId);
				break;
			case "நீ":
				pronoun=true;
				IntermediateOutput[i].rootWord="நீ";
				IntermediateOutput[i].POS="pronoun";
				IntermediateOutput[i].POSId=2;
				IntermediateOutput[i].doerSuffix="ஆய்";
				IntermediateOutput[i].doerSuffixId=3;
				System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord +"\n"+ "DoerSuffix :"+IntermediateOutput[i].doerSuffix +"\n"+ "DoerSuffixid :"+IntermediateOutput[i].doerSuffixId);
				break;
			case "நீர்":
				pronoun=true;
				IntermediateOutput[i].rootWord="நீர்";
				IntermediateOutput[i].POS="pronoun";
				IntermediateOutput[i].POSId=2;
				IntermediateOutput[i].doerSuffix="ஈர்";
				IntermediateOutput[i].doerSuffixId=4;
				System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord +"\n"+ "DoerSuffix :"+IntermediateOutput[i].doerSuffix +"\n"+ "DoerSuffixid :"+IntermediateOutput[i].doerSuffixId);
				break;
			case "நீங்கள்":
				pronoun=true;
				IntermediateOutput[i].rootWord="நீங்கள்";
				IntermediateOutput[i].POS="pronoun";
				IntermediateOutput[i].POSId=2;
				IntermediateOutput[i].doerSuffix="ஈர்கள்";
				IntermediateOutput[i].doerSuffixId=5;
				System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord +"\n"+ "DoerSuffix :"+IntermediateOutput[i].doerSuffix +"\n"+ "DoerSuffixid :"+IntermediateOutput[i].doerSuffixId);
				break;
			case "அவன்":
				pronoun=true;
				IntermediateOutput[i].rootWord="அவன்";
				IntermediateOutput[i].POS="pronoun";
				IntermediateOutput[i].POSId=2;
				IntermediateOutput[i].doerSuffix="ஆன்";
				IntermediateOutput[i].doerSuffixId=6;
				System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord +"\n"+ "DoerSuffix :"+IntermediateOutput[i].doerSuffix +"\n"+ "DoerSuffixid :"+IntermediateOutput[i].doerSuffixId);
				break;
			case "அவள்":
				pronoun=true;
				IntermediateOutput[i].rootWord="அவள்";
				IntermediateOutput[i].POS="pronoun";
				IntermediateOutput[i].POSId=2;
				IntermediateOutput[i].doerSuffix="ஆள்";
				IntermediateOutput[i].doerSuffixId=7;
				System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord +"\n"+ "DoerSuffix :"+IntermediateOutput[i].doerSuffix +"\n"+ "DoerSuffixid :"+IntermediateOutput[i].doerSuffixId);
				break;
			case "அவர்":
				pronoun=true;
				IntermediateOutput[i].rootWord="அவர்";
				IntermediateOutput[i].POS="pronoun";
				IntermediateOutput[i].POSId=2;
				IntermediateOutput[i].doerSuffix="ஆர்";
				IntermediateOutput[i].doerSuffixId=8;
				System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord +"\n"+ "DoerSuffix :"+IntermediateOutput[i].doerSuffix +"\n"+ "DoerSuffixid :"+IntermediateOutput[i].doerSuffixId);
				break;
			case "அவர்கள்":
				pronoun=true;
				IntermediateOutput[i].rootWord="அவர்கள்";
				IntermediateOutput[i].POS="pronoun";
				IntermediateOutput[i].POSId=2;
				IntermediateOutput[i].doerSuffix="ஆர்கள்";
				IntermediateOutput[i].doerSuffixId=9;
				System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord +"\n"+ "DoerSuffix :"+IntermediateOutput[i].doerSuffix +"\n"+ "DoerSuffixid :"+IntermediateOutput[i].doerSuffixId);
				break;
			case "அது":
				pronoun=true;
				IntermediateOutput[i].rootWord="அது";
				IntermediateOutput[i].POS="pronoun";
				IntermediateOutput[i].POSId=2;
				IntermediateOutput[i].doerSuffix="அது";
				IntermediateOutput[i].doerSuffixId=11;
				System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord +"\n"+ "DoerSuffix :"+IntermediateOutput[i].doerSuffix +"\n"+ "DoerSuffixid :"+IntermediateOutput[i].doerSuffixId);
				break;
			case "அவை":
				pronoun=true;
				IntermediateOutput[i].rootWord="அவை";
				IntermediateOutput[i].POS="pronoun";
				IntermediateOutput[i].POSId=2;
				IntermediateOutput[i].doerSuffix="அன";
				IntermediateOutput[i].doerSuffixId=12;
				System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord +"\n"+ "DoerSuffix :"+IntermediateOutput[i].doerSuffix +"\n"+ "DoerSuffixid :"+IntermediateOutput[i].doerSuffixId);
				break;
			case "அவைகள்":
				pronoun=true;
				IntermediateOutput[i].rootWord="அவைகள்";
				IntermediateOutput[i].POS="pronoun";
				IntermediateOutput[i].POSId=2;
				IntermediateOutput[i].doerSuffix="அன";
				IntermediateOutput[i].doerSuffixId=12;
				System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord +"\n"+ "DoerSuffix :"+IntermediateOutput[i].doerSuffix +"\n"+ "DoerSuffixid :"+IntermediateOutput[i].doerSuffixId);
				break;
			}
			if(pronoun)
			{	checkDB(IntermediateOutput[i]);
			continue;}

			//Inflected பெயர்சொல் 
			pat = Pattern.compile("(லை|லால்|லுக்கு|லில்|லின்|லினது|ற்கள்|ற்களால்|லின்கண்|பை|பால்|புக்கு|பிற்கு|பில்|பின்|பினது|புகள்|புகளால்|பின்கண்|ட்டை|ட்டால்|ட்டுக்கு|ட்டிற்கு|ட்டில்|ட்டின்|ட்டினது|டுகள்|டுகளால்|ட்டின்கண்|கை|கால்|கிற்கு|குக்கு|கில்|கின்|கினது|கள்|களால்|கின்கண்|யை|யால்|க்கு|யில்|யின்|யினது|யின்கண்|த்தை|த்தால்|த்துக்கு|த்தில்|த்தின்|த்தினது|த்தின்கண்)$");
			matcher = pat.matcher(words[i]);    
			if(matcher.find()){
				IntermediateOutput[i] = Noun.analyse(words[i]);
				IntermediateOutput[i].inflectedWord=words[i];
				checkDB(IntermediateOutput[i]);
				continue;
			}

			//Adverb
			pat = Pattern.compile("ாக$");
			matcher = pat.matcher(words[i]);    
			if(matcher.find()){
				IntermediateOutput[i].rootWord=words[i];
				IntermediateOutput[i].POS="adverb";
				IntermediateOutput[i].POSId=4;
				System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord);

				checkDB(IntermediateOutput[i]);
				continue;
			}

			//Adjective
			pat = Pattern.compile("(ான|ய|நீண்ட)$");
			matcher = pat.matcher(words[i]);    
			if(matcher.find()){
				IntermediateOutput[i].rootWord=words[i];
				IntermediateOutput[i].POS="adjective";
				IntermediateOutput[i].POSId=5;
				System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord);

				checkDB(IntermediateOutput[i]);
				continue;
			}	

			//எச்சம்
			pat = Pattern.compile("(த்த|த்து|ந்த|ந்து|ப்பு|ட|டு|ற்ற|ற்று|கிற|கின்ற|ரும்|லும்|ளும்|க்கும்|கும்)$");
			matcher = pat.matcher(words[i]);        
			if(matcher.find())
			{
				IntermediateOutput[i] = Echam.analyse(words[i]);
				IntermediateOutput[i].inflectedWord=words[i];
				checkDB(IntermediateOutput[i]);
				continue;
			}
			//Mostly a named entity
			IntermediateOutput[i].rootWord=words[i];
			IntermediateOutput[i].POS="subject";
			IntermediateOutput[i].POSId=0;
			System.out.println("\n"+ words[i] +"\n"+ "POS :"+IntermediateOutput[i].POS +"\n"+ "POSid :"+IntermediateOutput[i].POSId  +"\n"+ "rootword: "+IntermediateOutput[i].rootWord);

			checkDB(IntermediateOutput[i]);
			continue;
		}
		return IntermediateOutput;
	}
	private void checkDB(SegmentedWord segmentedWord) {
		try{ 
			String url = "jdbc:mysql://localhost:3306/"; 
			String dbName = "tamilwordnet"; 
			String driver = "com.mysql.jdbc.Driver"; 
			String userName = "root"; 
			String password = "";
			Class.forName(driver).newInstance(); 
			Connection conn = DriverManager.getConnection(url+dbName+"?characterEncoding=UTF-8",userName,password);
			Statement st = conn.createStatement();
			String query = "SELECT * FROM sense"+" where"+" label like "+"'"+segmentedWord.inflectedWord+"';";
			System.out.println(query);
			ResultSet res = st.executeQuery(query); 
			while(res.next()){
				String dbPOS = res.getString(2);
				System.err.println(segmentedWord.inflectedWord+"\t"+dbPOS);
			}

			query = "SELECT * FROM sense"+" where"+" label like "+"'"+segmentedWord.rootWord+"';";
			System.out.println(query);
			res = st.executeQuery(query); 
			while(res.next()){
				String dbPOS = res.getString(2);
				System.err.println(segmentedWord.rootWord+"\t"+dbPOS);
			}
		}catch(Exception e){
			e.printStackTrace();
		}

	}
	public static void main(String args[]){
		analyser a = new analyser();
		a.analyzeText("சீதைக்கு மோதிரத்தை கொடுத்தான்");
//		a.analyzeText("அவன் புத்தகத்தை படிப்பான்");	
//		a.analyzeText("கண்ணகி மதுரையை எரித்தாள்");
//		a.analyzeText("பரத் கீழே விழுந்தான்");
//		a.analyzeText("நான் சாந்தோம் சென்றேன்");
		System.out.println("Completed");
	}
}
