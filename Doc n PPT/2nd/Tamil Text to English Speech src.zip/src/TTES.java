import analyser.*;
import UNLDeConverter.*;
import UNLEnCoverter.*;
import UNLWordFormat.UNLGraph;
import voiceGenerator.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

public class TTES extends JFrame {

	private static final long serialVersionUID = 1L;

	public TTES()
	{

	}

	public static void main(String[] args) {
		//  UI instantiation	
		try {
			Runtime.getRuntime().exec("cmd /c start C:\\Users\\mrsiva268\\MARYTTS\\bin\\maryserver.bat");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		JFrame user=new JFrame("Tamil text to English Emotional Speech");
		user.setSize(1000, 1000);
		JPanel mainpanel=new JPanel();
		mainpanel.setSize(1000,1000);
		mainpanel.setLayout(new BoxLayout(mainpanel, BoxLayout.Y_AXIS));
		user.setDefaultCloseOperation(EXIT_ON_CLOSE);
		JLabel inputLabel=new JLabel("மொழி மாற்றதுக்கான வரியை பதிவு செய்க");
		System.out.println("மொழி மாற்றதுக்கான வரியை பதிவு செய்க");
		mainpanel.add(inputLabel,BorderLayout.CENTER);
		JTextField input=new JTextField(40);
		mainpanel.add(input,BorderLayout.CENTER);
		JButton translateButton=new JButton("Translate");
		JLabel unlgraph=new JLabel("UNL");
		mainpanel.add(unlgraph,BorderLayout.CENTER);
		unlgraph.setText("UNL GRAPH");
		JTextField output=new JTextField(40);
		mainpanel.add(output,BorderLayout.CENTER);
		output.setText("Output");
		translateButton.setPreferredSize(new Dimension(10,40));
		mainpanel.add(translateButton,BorderLayout.CENTER);

		//		 JLabel UNLLabel=new JLabel("UNL");
		//		 mainpanel.add(UNLLabel,BorderLayout.CENTER);
		//		 UNLLabel.setText("<html>Hi <br> how are <br> you</html>");

		System.out.println("மொழி மாற்றதுக்கான வரியை பதிவு செய்க");

		translateButton.addActionListener( new ActionListener(){
			@Override public void actionPerformed(ActionEvent e) {

				System.out.println("input"+input.getText());
				SegmentedWord intermediateOutput[];
				String englishEquivalent;
				UNLGraph intermediateGraph;
				intermediateOutput=new analyser().analyzeText(input.getText());
				intermediateGraph=new UNLEnConverter().enconvert(intermediateOutput);
				unlgraph.setText("<html>"+intermediateGraph.getUNL().replaceAll("\n", "<br>")+"</html>");
				englishEquivalent=new UNLDeConverter().deconvert(intermediateGraph);
				output.setText(englishEquivalent);
				String voiceOutputPath="E:\\fyp\\output\\"+englishEquivalent.replaceAll(" ", "")+"wav";
				new voiceGenerator().generateVoice(intermediateGraph,englishEquivalent,voiceOutputPath);
			}
		});
		user.setContentPane(mainpanel);
		user.pack(); 
		user.setVisible(true);
	}

}
