package UNLWordFormat;


public class SimpleNode extends UNLNode {
	String word;
	String attributes[];
	String tense;
	Integer attributes_id[];
	int number_of_attributes;
	
	public SimpleNode(String root)
	{
		this.word=root;
		this.type=0;
		this.tense=null;
		this.number_of_attributes=0;
		attributes=new String[20];
	}
	
	public void addAttribute(String att)
	{
		attributes[number_of_attributes++]=(att);
	
		if(att=="present")
			this.tense="present";
		else if(att=="past")
			this.tense="past";
		else if(att=="future")
			this.tense="future";
		
		//System.out.println("Adding tense"+this.tense);
		//this.attributes_id.add(ID_MAP(attribute));
	}
	public String getRoot()
	{
		return word;
	}
	
	public String[] getAttributes()
	{
		return attributes;
	}
	
	public String printAttributes()
	{
		String str="";
		for(int i=0;i<this.number_of_attributes;i++)
		{
			str=str+" @"+attributes[i];
		}
		return str;
	}
	
	public String printNode()
	{
		return word+this.printAttributes();
	}
	
	public String getTense()
	{
	//	System.out.println("getting tense"+this.tense);
		return this.tense;
	}
	
}