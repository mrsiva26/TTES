package UNLWordFormat;
import java.util.HashMap;

/* now including only the attributes that i can identify */

public interface constants{
	
	HashMap<Integer,String> attribute_map=new  HashMap<Integer,String>();
	//attribute_map.put(1,'a');
	
	
}
